# MeetPoint App

Mobile app for spontaneous meetups over drinks or coffee.

## Stack
- React Native + Expo
- Firebase (Auth + Firestore)
